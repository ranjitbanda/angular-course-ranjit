'use strict';
var teachBtn = document.getElementById('teachBtn');

var firstHotel = {
  getFood(cb){
    setTimeout(function(){
      cb('Biryani is ready......')
    }, 10000);
  }
};

var secondHotel = {
  getFood(cb){
    setTimeout(function(){
      cb('Starters are ready......')
    }, 5000);
  }
};

teachBtn.addEventListener('click', function(e){
  console.log('Team went to Mall');
  console.log('Ambience is good, feels hungry....ordered food');
  firstHotel.getFood((cbArg) => console.log(cbArg)); //async call
  secondHotel.getFood((cbArg) => console.log(cbArg)); //async call
  console.log('promise created, deferring actions to future = ordered items waiting');
  console.log('further waiting for the food to come');
});





// Via callbacks
/*
 function doAsyncTask(cb) {
 setTimeout(() => {
 console.log("Async Task Calling Callback");
 cb();
 }, 1000);
 }

 doAsyncTask(() => console.log("Callback Called"));
 */


/*
// Via Promise
let error = false;
function doAsyncTask() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (error) {
        reject('error');
      } else {
        resolve('done');
      }
    }, 1000);
  });
}

doAsyncTask().then(
    (val) => console.log(val),
    (err) => console.error(err)
);

// Immediately Resolved Promise
let promise = Promise.resolve('done');
promise.then((val) => console.log(val)); // 'done'

// Handling Errors
Promise.resolve('done')
    .then((val) => {throw new Error("fail")})
    .then((val) => console.log(val))
    .catch((err) => console.error(err));

    */